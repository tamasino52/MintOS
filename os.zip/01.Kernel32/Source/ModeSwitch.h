
#ifndef __MODESWITCH_H__
#define __MODESWITCH_H__

#include "Types.h"


void kSwitchAndExecute64bitKernel( void );


#endif /*__MODESWITCH_H__*/
